title: java 归并排序
date: '2019-11-17 21:52:34'
updated: '2019-11-17 21:54:29'
tags: [数据结构和算法]
permalink: /articles/2019/11/17/1573998754235.html
---


```
package com.base;

/**
 * 递归排序
 */
public class DArray {
    private long[] theArray;
    private int nElem;

    public DArray(int max) {
        theArray = new long[max];
        nElem = 0;
    }

    public void insert(long value) {
        theArray[nElem] = value;
        nElem ++;
    }

    public void disPlay() {
        for(int j = 0; j < nElem; j ++) {
            System.out.print(theArray[j] + " ");
        }
        System.out.println();
    }


    private void mergeSort() {
        long[] workSpace = new long[nElem];
        reMergeSort(workSpace,0, nElem - 1);
    }

    private void reMergeSort(long[] workSpace, int lowBound, int highBound) {
        if(lowBound == highBound) {
            return;
        } else {
            int mid = (lowBound + highBound) / 2;
            reMergeSort(workSpace, lowBound, mid);
            reMergeSort(workSpace, mid + 1, highBound);
            merge(workSpace, lowBound, mid + 1, highBound);
        }
    }

    private void merge(long[] workSpace, int lowPre, int highPre, int highBound) {
        int j = 0;
        int lowbound = lowPre;
        int mid = highPre - 1;
        int n = highBound - lowbound + 1;

        while (lowPre <= mid && highPre <= highBound) {
            if(theArray[lowPre] < theArray[highPre]) {
                workSpace[j ++] = theArray[lowPre ++];
            } else {
                workSpace[j ++] = theArray[highPre ++];
            }
        }

        while (lowPre <= mid) {
            workSpace[j++] = theArray[lowPre ++];
        }

        while (highPre <= highBound) {
            workSpace[j ++] = theArray[highPre ++];
        }

        for(j = 0; j < n; j ++) {
            theArray[lowbound ++] = workSpace[j];
        }
    }


    public static void main(String[] args) {
        int max = 100;
        DArray dArray = new DArray(max);

        dArray.insert(64);
        dArray.insert(1);
        dArray.insert(30);
        dArray.insert(40);
        dArray.insert(51);
        dArray.insert(100);
        dArray.insert(20);

        dArray.disPlay();

        dArray.mergeSort();

        dArray.disPlay();
    }
}

```
