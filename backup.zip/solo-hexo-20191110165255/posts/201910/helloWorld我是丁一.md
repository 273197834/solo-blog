title: hello World ！我是丁一
date: '2019-10-12 23:48:36'
updated: '2019-10-15 13:27:53'
tags: [待分类]
permalink: /articles/2019/10/12/1570895316218.html
---
![](https://img.hacpai.com/bing/20190917.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


hello World!

我是 丁一
