title: java 合并两个有序数组
date: '2019-10-31 18:07:11'
updated: '2019-10-31 18:07:11'
tags: [java]
permalink: /articles/2019/10/31/1572516431462.html
---
````
package base;

/**
 * java 合并两个有序数组
 */
public class MergeTwoArray {
    public static void main(String[] args) {
        int[] arrayA = {100,200,201,334};
        int[] arrayB = {101,104,106,233,455,772};
        int[] arrayC = new int[arrayA.length + arrayB.length];
        merge(arrayA,arrayA.length,arrayB,arrayB.length,arrayC);
        disPlay(arrayC);
    }

    public static void merge(int[] arrayA, int sizeA, int[] arrayB, int sizeB,int[] arrryC) {
        int aIndex = 0, bIndex = 0,cIndex = 0;
        while (aIndex < sizeA && bIndex < sizeB) {
            if(arrayA[aIndex] < arrayB[bIndex]) {
                arrryC[cIndex ++] = arrayA[aIndex++];
            } else {
                arrryC[cIndex ++] = arrayB[bIndex++];
            }
        }
        while (aIndex < sizeA) {
            arrryC[cIndex ++] = arrayA[aIndex++];
        }
        while (bIndex < sizeB) {
            arrryC[cIndex ++] = arrayB[bIndex ++];
        }
    }

    public static void disPlay(int[] arryx) {
        for(int i = 0; i < arryx.length; i ++) {
            System.out.print(arryx[i] + " ");
        }
        System.out.println();
    }
}

````
