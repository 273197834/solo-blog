title: java实现汉诺塔
date: '2019-10-22 19:49:25'
updated: '2019-10-23 14:16:33'
tags: [数据结构和算法]
permalink: /articles/2019/10/22/1571744965114.html
---
```
package base;

import java.util.Scanner;

public class TowerApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("please input a integer number : ");
            int x = scanner.nextInt();
            if(x == 0) {
                System.out.println("quit");
                break;
            }
            x = Math.abs(x);
            doTowers(x, 'A','B','C');
        }
    }

    public static void doTowers(int topN, char from, char iner, char to) {

        if(topN == 1) {
            System.out.println("disk 1 from " + from + " to " + to);
        } else {
            doTowers(topN -1, from, to,iner);
            System.out.println("disk " + topN + " from " + from + " to " + to);
            doTowers(topN -1, iner, from, to);
        }

    }
}
```
